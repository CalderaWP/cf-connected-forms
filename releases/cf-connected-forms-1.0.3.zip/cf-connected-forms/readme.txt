=== Form Connector For Caldera Forms ===
Contributors: Shelob9
Donate link: https://CalderaWP.com
Tags: forms, caldera forms, Caldera Forms, wpform
Requires at least: 4.3
Tested up to: 4.4
Stable tag: 0.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Changelog ==

= 1.0.3 =
Improved compatibility with core plugin version 1.3.2+

= 1.0.2 =
* Fixed bug affecting entry output.

= 1.0.1 =
* Fix bug preventing forms without conditional logic from being loaded.

= 1.0.0 =
* Initial release
